package com.example.lifemart

abstract class modelClass {

}