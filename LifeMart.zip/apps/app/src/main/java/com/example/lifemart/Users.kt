package com.example.lifemart



data class Users(
    val pic:String?=null,
    val fullName:String?=null,
    val workMail:String?=null,
    val workNumber:String?=null,
    val position:String?=null
)
