package com.example.lifemart



data class Users1(
    val name1:String?=null,
    val title1:String?=null,
    val description1:String?=null,
    val description2:String?=null,
    val description3:String?=null
)
